package com.example.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;

import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

import static android.content.ContentValues.TAG;

public class add_event extends Activity {

    private static int RESULT_LOAD_IMAGE = 1;
    boolean check1;
    boolean check2;
    boolean Wolontariaty;
    boolean Motoryzacja;
    boolean Komedia;
    boolean Sportowe;
    boolean Zakupy;
    boolean Zdrowie;
    boolean Fitness;
    boolean Muzyka;
    boolean Impreza;
    boolean Fikcyjne;
    boolean Inne;
    String message;
    CheckBox c1;
    CheckBox c2;
    CheckBox c3;
    CheckBox c4;
    CheckBox c5;
    CheckBox c6;
    CheckBox c7;
    CheckBox c8;
    CheckBox c9;
    CheckBox c10;
    CheckBox c11;
    private DatabaseReference mDatabase;
    public Bitmap selectedImage;
    public Uri imageUri;
    String desc;
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference();
    int eventtype;
    int join;
    int follow;
    int relation;
    int relationview;
    int saveandcomment;
    UploadTask uploadTask;
    String nazwa;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    StorageReference mountainImagesRef = storageRef.child("images/mountains.jpg");
    String opis;
    public void SetImage(View view)
    {
        String[] options = {"Dodaj Zdjęcie z Galerii", "Dodaj Zdjęcie z Aparatu"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Co robimy ?");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if ("Dodaj Zdjęcie z Galerii".equals(options[which])) {
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    Uri uri = pickPhoto.getData();
                    upload(uri);
                }
                else if ("Dodaj Zdjęcie z Aparatu".equals(options[which]))
                {
                   // Intent takePhoto = new Intent(android.media.action. );
                    //Uri uri = takePhoto.getData();
                   // upload(uri);
                }
            }
        });
        builder.show();
    }
    public void upload(Uri uri)
    {
        UploadTask uploadTask = mountainImagesRef.putFile(uri);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle unsuccessful uploads
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                // ...
            }
        });
    }
    public static class Post {

        public String author;
        public String title;

        public Post(String author, String title) {
            // ...
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        mDatabase = FirebaseDatabase.getInstance().getReference();
    }

    public void Madafaka(View view)
    {
        CheckBox cs = (CheckBox) findViewById(R.id.checkBox);
        TextView tv = (TextView) findViewById(R.id.textView23);
        if(cs.isChecked())
        {
            tv.setText("*Rolka z aparatu jest używana");
            Intent i = new Intent(
                    Intent.ACTION_PICK,
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

            startActivityForResult(i, RESULT_LOAD_IMAGE);
        }
        else
        {
            tv.setText("*Rolka z aparatu nie jest używana");
        }
    }
    public void writeNewUser(String userId, String name, String email) {
// ...
    }
    public void addevent(View view)
    {
        TextInputEditText TXT = findViewById(R.id.ko);
        TextInputEditText TXT2 = findViewById(R.id.opis);
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        CheckBox otwarty = findViewById(R.id.checkBox30);
        CheckBox zamkniety = findViewById(R.id.checkBox31);
        if (otwarty.isChecked())
        {
            eventtype = 1;
        }
        else if(zamkniety.isChecked())
        {
            eventtype = 2;
        }
        else
        {
            AlertDialog.Builder publiczne = new AlertDialog.Builder(this);
            publiczne.setTitle("Błąd");
            publiczne.setMessage("Nie został wybrany rodzaj wydarzenia");
            publiczne.setPositiveButton("Ok", null);
            AlertDialog dialog = publiczne.create();
            dialog.show();
        }
        mDatabase.child("events").child("eventype").setValue(eventtype);







        CheckBox nr15 = findViewById(R.id.checkBox15);
        CheckBox nr16 = findViewById(R.id.checkBox16);
        CheckBox nr17 = findViewById(R.id.checkBox17);
        CheckBox nr28 = findViewById(R.id.checkBox28);
        if (nr15.isChecked())
        {
            join = 1;
        }
        else if(nr16.isChecked())
        {
            join = 2;
        }
        else if(nr17.isChecked())
        {
            join = 3;
        }
        else if(nr28.isChecked())
        {
            join = 4;
        }
        else
        {
            AlertDialog.Builder publiczne = new AlertDialog.Builder(this);
            publiczne.setTitle("Błąd");
            publiczne.setMessage("Nie zostało wybrane kto może dołączyć do wydarzenia");
            publiczne.setPositiveButton("Ok", null);
            AlertDialog dialog = publiczne.create();
            dialog.show();
        }
        mDatabase.child("events").child("join").setValue(join);



        CheckBox nr18 = findViewById(R.id.checkBox18);
        CheckBox nr19 = findViewById(R.id.checkBox19);
        CheckBox nr20 = findViewById(R.id.checkBox20);
        CheckBox nr27 = findViewById(R.id.checkBox27);
        if (nr18.isChecked())
        {
            follow = 1;
        }
        else if(nr19.isChecked())
        {
            follow = 2;
        }
        else if(nr20.isChecked())
        {
            follow = 3;
        }
        else if(nr27.isChecked())
        {
            follow = 4;
        }
        else
        {
            AlertDialog.Builder publiczne = new AlertDialog.Builder(this);
            publiczne.setTitle("Błąd");
            publiczne.setMessage("Nie zostało wybrane kto może oberwowac wydarzenie");
            publiczne.setPositiveButton("Ok", null);
            AlertDialog dialog = publiczne.create();
            dialog.show();
        }
        mDatabase.child("events").child("follow").setValue(follow);



        CheckBox y1 = findViewById(R.id.checkBox21);
        CheckBox n1 = findViewById(R.id.checkBox22);
        if (y1.isChecked())
        {
            relation = 1;
        }
        else if(n1.isChecked())
        {
            relation = 2;
        }
        else
        {
            AlertDialog.Builder publiczne = new AlertDialog.Builder(this);
            publiczne.setTitle("Błąd");
            publiczne.setMessage("Nie zostało wybrane kto może relacjonować wydarzenie");
            publiczne.setPositiveButton("Ok", null);
            AlertDialog dialog = publiczne.create();
            dialog.show();
        }
        mDatabase.child("events").child("relation").setValue(relation);

        CheckBox r1 = findViewById(R.id.checkBox24);
        CheckBox r2 = findViewById(R.id.checkBox23);
        CheckBox r3 = findViewById(R.id.checkBox29);
        if (r1.isChecked())
        {
            relationview = 1;
        }
        else if(r2.isChecked())
        {
            relationview = 2;
        }
        else if(r3.isChecked())
        {
            relationview = 3;
        }
        else
        {
            AlertDialog.Builder publiczne = new AlertDialog.Builder(this);
            publiczne.setTitle("Błąd");
            publiczne.setMessage("Nie wybrano widocznosci wydarzenia");
            publiczne.setPositiveButton("Ok", null);
            AlertDialog dialog = publiczne.create();
            dialog.show();
        }
        mDatabase.child("events").child("relationview").setValue(relationview);



        CheckBox v1 = findViewById(R.id.checkBox25);
        CheckBox v2 = findViewById(R.id.checkBox26);
        if (v1.isChecked())
        {
            saveandcomment = 1;
        }
        else if(v2.isChecked())
        {
            saveandcomment = 2;
        }
        else
        {
            AlertDialog.Builder publiczne = new AlertDialog.Builder(this);
            publiczne.setTitle("Błąd");
            publiczne.setMessage("Nie zostało wybrane kto może zapisywać i komentowac wydarzenie");
            publiczne.setPositiveButton("Ok", null);
            AlertDialog dialog = publiczne.create();
            dialog.show();
        }
        mDatabase.child("events").child("saveandcomment").setValue(saveandcomment);

        TextInputEditText name = findViewById(R.id.ko);
        TextInputEditText txdesc = findViewById(R.id.opis1);
        nazwa = name.getText().toString();
        opis = txdesc.getText().toString();
        mDatabase.child("events").child("name").setValue(nazwa);
        mDatabase.child("events").child("description").setValue(opis);


    }
    public void addpublicevent(View view)
    {
        CheckBox wolonotariaty = findViewById(R.id.checkBox4);
        CheckBox Motoryzacja = findViewById(R.id.checkBox5);
        CheckBox Komedia = findViewById(R.id.checkBox6);
        CheckBox Sportowe = findViewById(R.id.checkBox7);
        CheckBox Zakupy = findViewById(R.id.checkBox8);
        CheckBox Zdrowie = findViewById(R.id.checkBox9);
        CheckBox Fitness = findViewById(R.id.checkBox10);
        CheckBox Muzyka = findViewById(R.id.checkBox11);
        CheckBox Impreza = findViewById(R.id.checkBox12);
        CheckBox Fikcyjne = findViewById(R.id.checkBox13);
        CheckBox Inne = findViewById(R.id.checkBox14);
        TextInputEditText txted = findViewById(R.id.txtpriv);
        TextInputEditText txted1 = findViewById(R.id.opis);
        if(wolonotariaty.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("wolonotariaty").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("wolonotariaty").setValue("0");
        }
        if(Motoryzacja.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Motoryzacja").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Motoryzacja").setValue("0");
        }
        if(Komedia.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Komedia").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Komedia").setValue("0");
        }

        if(Sportowe.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Sportowe").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Sportowe").setValue("0");
        }

        if(Zakupy.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Zakupy").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Zakupy").setValue("0");
        }

        if(Zdrowie.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Zdrowie").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Zdrowie").setValue("0");
        }

        if(Fitness.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Fitness").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Fitness").setValue("0");
        }

        if(Muzyka.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Muzyka").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Muzyka").setValue("0");
        }

        if(Impreza.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Impreza").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Impreza").setValue("0");
        }

        if(Fikcyjne.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Fikcyjne").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Fikcyjne").setValue("0");
        }

        if(Inne.isChecked())
        {
            mDatabase.child("events").child("public").child("event1").child("Inne").setValue("1");
        }
        else
        {
            mDatabase.child("events").child("public").child("event1").child("Inne").setValue("0");
        }
        String name = txted.getText().toString();
        String opis = txted1.getText().toString();
        mDatabase.child("events").child("public").child("event1").child("name").setValue(name);
        mDatabase.child("events").child("public").child("event1").child("desc").setValue(opis);
        finish();
    }
    public void open(View view)
    {
        Intent i = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(i, RESULT_LOAD_IMAGE);
    }
    public void publiczne(View view)
    {
        CheckBox bb = findViewById(R.id.checkBox2);
        CheckBox b2 = findViewById(R.id.checkBox3);
        NestedScrollView n2 = findViewById(R.id.nse2);
        NestedScrollView n1 = findViewById(R.id.priva);
        if(check1 == false)
        {
            b2.setEnabled(false);
            check2 = false;
            check1 = true;
            n2.setVisibility(View.VISIBLE);
        }
        else if(check1 == true)
        {
            b2.setEnabled(true);
            check2 = false;
            check1 = false;
            n2.setVisibility(View.INVISIBLE);
        }
    }
    public void privatee(View view)
    {
        CheckBox bb = findViewById(R.id.checkBox2);
        CheckBox b2 = findViewById(R.id.checkBox3);
        NestedScrollView n1 = findViewById(R.id.priva);
        if(check2 == false)
        {
            bb.setEnabled(false);
            check1 = false;
            check2 = true;
            n1.setVisibility(View.VISIBLE);
        }
        else if(check2 == true)
        {
            bb.setEnabled(true);
            check1 = false;
            check2 = false;
            n1.setVisibility(View.INVISIBLE);
        }
    }
    public void wolo(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Wolontariaty == false)
        {
            Wolontariaty=true;
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Wolontariaty==true)
        {
            Wolontariaty=false;
            c2.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void moto(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Motoryzacja == false)
        {
            Motoryzacja=true;
            c1.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Motoryzacja==true)
        {
            Motoryzacja = false;
            c1.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void comedy(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Komedia == false)
        {
            Komedia=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Komedia==true)
        {
            Komedia = false;
            c1.setEnabled(true);
            c2.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void sportow(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Sportowe == false)
        {
            Sportowe=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Sportowe==true)
        {
            Sportowe=false;
            c1.setEnabled(true);
            c2.setEnabled(true);
            c3.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void buy(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Zakupy == false)
        {
            Zakupy=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Zakupy==true)
        {
            Zakupy=false;
            c1.setEnabled(true);
            c2.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void health(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Zdrowie == false)
        {
            Zdrowie=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Zdrowie==true)
        {
            Zdrowie=false;
            c1.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void fitness(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Fitness == false)
        {
            Fitness=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Fitness==true)
        {
            Fitness=false;
            c1.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void music(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Muzyka == false)
        {
            Muzyka=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Muzyka==true)
        {
            Muzyka=false;
            c1.setEnabled(true);
            c2.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void party(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Impreza == false)
        {
            Impreza=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c10.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Impreza==true)
        {
            Impreza=false;
            c1.setEnabled(true);
            c2.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c10.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void Fikcyjne(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Fikcyjne == false)
        {
            Fikcyjne=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c11.setEnabled(false);
        }
        else if(Fikcyjne==true)
        {
            Fikcyjne=false;
            c1.setEnabled(true);
            c2.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c11.setEnabled(true);
        }
    }
    public void other(View view)
    {
        c1 = findViewById(R.id.checkBox4);
        c2 = findViewById(R.id.checkBox5);
        c3 = findViewById(R.id.checkBox6);
        c4 = findViewById(R.id.checkBox7);
        c5 = findViewById(R.id.checkBox8);
        c6 = findViewById(R.id.checkBox9);
        c7 = findViewById(R.id.checkBox10);
        c8 = findViewById(R.id.checkBox11);
        c9 = findViewById(R.id.checkBox12);
        c10 = findViewById(R.id.checkBox13);
        c11 = findViewById(R.id.checkBox14);
        if(Inne == false)
        {
            Inne=true;
            c1.setEnabled(false);
            c2.setEnabled(false);
            c3.setEnabled(false);
            c4.setEnabled(false);
            c5.setEnabled(false);
            c6.setEnabled(false);
            c7.setEnabled(false);
            c8.setEnabled(false);
            c9.setEnabled(false);
            c10.setEnabled(false);
        }
        else if(Inne==true)
        {
            Inne=false;
            c1.setEnabled(true);
            c2.setEnabled(true);
            c3.setEnabled(true);
            c4.setEnabled(true);
            c5.setEnabled(true);
            c6.setEnabled(true);
            c7.setEnabled(true);
            c8.setEnabled(true);
            c9.setEnabled(true);
            c10.setEnabled(true);
        }
    }
    public void Observe (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        observa.setTextColor(Color.rgb(178, 178, 178));
        forme.setTextColor(Color.rgb(0, 0, 0));
    }
    public void forme (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        forme.setTextColor(Color.rgb(178, 178, 178));
        observa.setTextColor(Color.rgb(0, 0, 0));
    }
    public void Events (View view)
    {
        Intent ss = new Intent(add_event.this, activity_event.class);
        add_event.this.startActivity(ss);
    }
    public void map (View view)
    {
        Intent ss = new Intent(add_event.this, MapsActivity.class);
        add_event.this.startActivity(ss);
    }
    public void odkrywaj (View view)
    {
        Intent ss = new Intent(add_event.this, Search.class);
        add_event.this.startActivity(ss);
    }
    public void create (View view)
    {
        Intent ss = new Intent(add_event.this, add_event.class);
        add_event.this.startActivity(ss);
    }
    public void help (View view)
    {
        CheckBox publi = findViewById(R.id.checkBox2);
        CheckBox priv = findViewById(R.id.checkBox3);
        if(publi.isChecked())
        {
            AlertDialog.Builder publiczne = new AlertDialog.Builder(this);
            publiczne.setTitle("Pomoc");
            publiczne.setMessage("Publiczne wydarzenia są wydarzeniami otwartymi do których może dołączyć każdy użytkownik Xvent. Każdy może obserwować, relacjonować te wydarznie, polecać, oceniać oraz komentować i zapisywać.");
            publiczne.setPositiveButton("Dzięki!", null);
            AlertDialog dialog = publiczne.create();
            dialog.show();
        }
        else if(priv.isChecked())
        {
            AlertDialog.Builder privat = new AlertDialog.Builder(this);
            privat.setTitle("Pomoc");
            privat.setMessage("Prywatne wydarzenia są wydarzeniami które dzielą się na otwarte i zamknięte. Wydarzenia otwarte są dostępne dla wszytkich bez ograniczeń i możliwośći edycji ich. W wydarzeniach zamkniętych możesz decydować o tym kto będzie mógł releacjnować, dołączać, obserwować, oceniać, zapisywać oraz zapraszać i komentować .");
            privat.setPositiveButton("Dzięki!", null);
            AlertDialog dialog = privat.create();
            dialog.show();
        }
        else
        {
            AlertDialog.Builder oth = new AlertDialog.Builder(this);
            oth.setTitle("Pomoc");
            oth.setMessage("Hej! Witaj w sekcji pomocy Edytora Wydarzeń aplikacji Xvent. Tutaj będziesz mógł stworzyć swoje własne wydarzenie zadecydować o jego właściowsciach oraz typie. Wyróźniamy 2 typy wydarzeń: Publiczne oraz Prywatne. Więcej pomocy o nich uzyskasz klikając mnie po wybraniu typu wydarzenia !");
            oth.setPositiveButton("Nie ma problemu!", null);
            AlertDialog dialog = oth.create();
            dialog.show();
        }
    }
    public void dw (View view)
    {
        CheckBox w = findViewById(R.id.checkBox15);
        CheckBox z = findViewById(R.id.checkBox16);
        CheckBox za = findViewById(R.id.checkBox17);
        if(w.isChecked())
        {
            z.setEnabled(false);
            za.setEnabled(false);
        }
        else
        {
            z.setEnabled(true);
            za.setEnabled(true);
        }
    }
    public void op(View view)
    {

        CheckBox cb15 = findViewById(R.id.checkBox15);
        CheckBox cb16 = findViewById(R.id.checkBox16);;
        CheckBox cb17 = findViewById(R.id.checkBox17);;
        CheckBox cb18 = findViewById(R.id.checkBox18);;
        CheckBox cb19 = findViewById(R.id.checkBox19);;
        CheckBox cb20 = findViewById(R.id.checkBox20);;
        CheckBox cb21 = findViewById(R.id.checkBox21);;
        CheckBox cb22 = findViewById(R.id.checkBox22);;
        CheckBox cb23 = findViewById(R.id.checkBox23);;
        CheckBox cb24 = findViewById(R.id.checkBox24);;
        CheckBox cb25 = findViewById(R.id.checkBox25);;
        CheckBox cb26 = findViewById(R.id.checkBox26);;
        CheckBox cb27 = findViewById(R.id.checkBox27);;
        CheckBox cb28 = findViewById(R.id.checkBox28);;
        CheckBox cb29 = findViewById(R.id.checkBox29);;
        CheckBox cb30 = findViewById(R.id.checkBox30);;
        CheckBox cb31 = findViewById(R.id.checkBox31);;
        Button b1 = findViewById(R.id.button13);
        TextView tx1 = findViewById(R.id.textView32);
        TextView tx2 = findViewById(R.id.textView33);
        TextView tx3 = findViewById(R.id.textView34);
        TextView tx4 = findViewById(R.id.textView35);
        TextView tx5 = findViewById(R.id.textView36);
        TextView tx6 = findViewById(R.id.textView40);
        TextView tx7 = findViewById(R.id.textView41);
        TextView tx8 = findViewById(R.id.textView42);
        TextView tx9 = findViewById(R.id.textView43);

        if(cb30.isChecked())
        {
            cb30.setEnabled(true);
            cb31.setEnabled(false);
            cb15.setEnabled(false);
            cb16.setEnabled(false);
            cb17.setEnabled(false);
            cb18.setEnabled(false);
            cb19.setEnabled(false);
            cb20.setEnabled(false);
            cb21.setEnabled(false);
            cb22.setEnabled(false);
            cb23.setEnabled(false);
            cb24.setEnabled(false);
            cb25.setEnabled(false);
            cb26.setEnabled(false);
            cb27.setEnabled(false);
            cb28.setEnabled(false);
            cb29.setEnabled(false);
            cb15.setVisibility(view.VISIBLE);
            cb16.setVisibility(view.VISIBLE);
            cb17.setVisibility(view.VISIBLE);
            cb18.setVisibility(view.VISIBLE);
            cb19.setVisibility(view.VISIBLE);
            cb20.setVisibility(view.VISIBLE);
            cb21.setVisibility(view.VISIBLE);
            cb22.setVisibility(view.VISIBLE);
            cb23.setVisibility(view.VISIBLE);
            cb24.setVisibility(view.VISIBLE);
            cb25.setVisibility(view.VISIBLE);
            cb26.setVisibility(view.VISIBLE);
            cb27.setVisibility(view.VISIBLE);
            cb28.setVisibility(view.VISIBLE);
            cb29.setVisibility(view.VISIBLE);
            tx2.setVisibility(view.VISIBLE);
            tx3.setVisibility(view.VISIBLE);
            tx4.setVisibility(view.VISIBLE);
            tx5.setVisibility(view.VISIBLE);
            tx6.setVisibility(view.VISIBLE);
            tx7.setVisibility(view.VISIBLE);
            tx8.setVisibility(view.VISIBLE);
            tx9.setVisibility(view.VISIBLE);
            b1.setVisibility(view.VISIBLE);
            cb15.setChecked(true);
            cb18.setChecked(true);
            cb21.setChecked(true);
            cb24.setChecked(true);
            cb25.setChecked(true);
        }
        else
        {
            cb30.setEnabled(true);
            cb31.setEnabled(true);
            cb15.setVisibility(view.INVISIBLE);
            cb16.setVisibility(view.INVISIBLE);
            cb17.setVisibility(view.INVISIBLE);
            cb18.setVisibility(view.INVISIBLE);
            cb19.setVisibility(view.INVISIBLE);
            cb20.setVisibility(view.INVISIBLE);
            cb21.setVisibility(view.INVISIBLE);
            cb22.setVisibility(view.INVISIBLE);
            cb23.setVisibility(view.INVISIBLE);
            cb24.setVisibility(view.INVISIBLE);
            cb25.setVisibility(view.INVISIBLE);
            cb26.setVisibility(view.INVISIBLE);
            cb27.setVisibility(view.INVISIBLE);
            cb28.setVisibility(view.INVISIBLE);
            cb29.setVisibility(view.INVISIBLE);
            tx2.setVisibility(view.INVISIBLE);
            tx3.setVisibility(view.INVISIBLE);
            tx4.setVisibility(view.INVISIBLE);
            tx5.setVisibility(view.INVISIBLE);
            tx6.setVisibility(view.INVISIBLE);
            tx7.setVisibility(view.INVISIBLE);
            tx8.setVisibility(view.INVISIBLE);
            tx9.setVisibility(view.INVISIBLE);
            b1.setVisibility(view.INVISIBLE);
            cb15.setChecked(false);
            cb18.setChecked(false);
            cb21.setChecked(false);
            cb24.setChecked(false);
            cb25.setChecked(false);
        }
    }
    public void otwa(View view)
    {
        CheckBox cb15 = findViewById(R.id.checkBox15);
        CheckBox cb16 = findViewById(R.id.checkBox16);;
        CheckBox cb17 = findViewById(R.id.checkBox17);;
        CheckBox cb18 = findViewById(R.id.checkBox18);;
        CheckBox cb19 = findViewById(R.id.checkBox19);;
        CheckBox cb20 = findViewById(R.id.checkBox20);;
        CheckBox cb21 = findViewById(R.id.checkBox21);;
        CheckBox cb22 = findViewById(R.id.checkBox22);;
        CheckBox cb23 = findViewById(R.id.checkBox23);;
        CheckBox cb24 = findViewById(R.id.checkBox24);;
        CheckBox cb25 = findViewById(R.id.checkBox25);;
        CheckBox cb26 = findViewById(R.id.checkBox26);;
        CheckBox cb27 = findViewById(R.id.checkBox27);;
        CheckBox cb28 = findViewById(R.id.checkBox28);;
        CheckBox cb29 = findViewById(R.id.checkBox29);;
        CheckBox cb30 = findViewById(R.id.checkBox30);;
        CheckBox cb31 = findViewById(R.id.checkBox31);;
        Button b1 = findViewById(R.id.button13);
        Button b2 = findViewById(R.id.button20);
        Button b3 = findViewById(R.id.button21);
        TextInputEditText tee = findViewById(R.id.ko);
        TextInputLayout twr = findViewById(R.id.TXT1);
        TextView tx1 = findViewById(R.id.textView32);
        TextView tx2 = findViewById(R.id.textView33);
        TextView tx3 = findViewById(R.id.textView34);
        TextView tx4 = findViewById(R.id.textView35);
        TextView tx5 = findViewById(R.id.textView36);
        TextView tx6 = findViewById(R.id.textView40);
        TextView tx7 = findViewById(R.id.textView41);
        TextView tx8 = findViewById(R.id.textView42);
        TextView tx9 = findViewById(R.id.textView43);
        if(cb31.isChecked())
        {
            cb30.setEnabled(false);
            cb31.setEnabled(true);
            cb15.setEnabled(true);
            cb16.setEnabled(true);
            cb17.setEnabled(true);
            cb18.setEnabled(true);
            cb19.setEnabled(true);
            cb20.setEnabled(true);
            cb21.setEnabled(true);
            cb22.setEnabled(true);
            cb23.setEnabled(true);
            cb24.setEnabled(true);
            cb25.setEnabled(true);
            cb26.setEnabled(true);
            cb27.setEnabled(true);
            cb28.setEnabled(true);
            cb29.setEnabled(true);
            cb15.setVisibility(view.VISIBLE);
            cb16.setVisibility(view.VISIBLE);
            cb17.setVisibility(view.VISIBLE);
            cb18.setVisibility(view.VISIBLE);
            cb19.setVisibility(view.VISIBLE);
            cb20.setVisibility(view.VISIBLE);
            cb21.setVisibility(view.VISIBLE);
            cb22.setVisibility(view.VISIBLE);
            cb23.setVisibility(view.VISIBLE);
            cb24.setVisibility(view.VISIBLE);
            cb25.setVisibility(view.VISIBLE);
            cb26.setVisibility(view.VISIBLE);
            cb27.setVisibility(view.VISIBLE);
            cb28.setVisibility(view.VISIBLE);
            cb29.setVisibility(view.VISIBLE);
            b1.setVisibility(view.VISIBLE);
            b2.setVisibility(view.VISIBLE);
            b3.setVisibility(view.VISIBLE);
            tx2.setVisibility(view.VISIBLE);
            tx3.setVisibility(view.VISIBLE);
            tx4.setVisibility(view.VISIBLE);
            tx5.setVisibility(view.VISIBLE);
            tx6.setVisibility(view.VISIBLE);
            tx7.setVisibility(view.VISIBLE);
            tx8.setVisibility(view.VISIBLE);
            tx9.setVisibility(view.VISIBLE);
            tee.setVisibility(view.VISIBLE);
            twr.setVisibility(view.VISIBLE);
        }
        else
        {
            cb30.setEnabled(true);
            cb15.setEnabled(false);
            cb16.setEnabled(false);
            cb17.setEnabled(false);
            cb18.setEnabled(false);
            cb19.setEnabled(false);
            cb20.setEnabled(false);
            cb21.setEnabled(false);
            cb22.setEnabled(false);
            cb23.setEnabled(false);
            cb24.setEnabled(false);
            cb25.setEnabled(false);
            cb26.setEnabled(false);
            cb27.setEnabled(false);
            cb28.setEnabled(false);
            cb29.setEnabled(false);
            cb15.setVisibility(view.INVISIBLE);
            cb16.setVisibility(view.INVISIBLE);
            cb17.setVisibility(view.INVISIBLE);
            cb18.setVisibility(view.INVISIBLE);
            cb19.setVisibility(view.INVISIBLE);
            cb20.setVisibility(view.INVISIBLE);
            cb21.setVisibility(view.INVISIBLE);
            cb22.setVisibility(view.INVISIBLE);
            cb23.setVisibility(view.INVISIBLE);
            cb24.setVisibility(view.INVISIBLE);
            cb25.setVisibility(view.INVISIBLE);
            cb26.setVisibility(view.INVISIBLE);
            cb27.setVisibility(view.INVISIBLE);
            cb28.setVisibility(view.INVISIBLE);
            cb29.setVisibility(view.INVISIBLE);
            b1.setVisibility(view.INVISIBLE);
            tx2.setVisibility(view.INVISIBLE);
            tx3.setVisibility(view.INVISIBLE);
            tx4.setVisibility(view.INVISIBLE);
            tx5.setVisibility(view.INVISIBLE);
            tx6.setVisibility(view.INVISIBLE);
            tx7.setVisibility(view.INVISIBLE);
            tx8.setVisibility(view.INVISIBLE);
            tx9.setVisibility(view.INVISIBLE);
            tee.setVisibility(view.INVISIBLE);
            twr.setVisibility(view.INVISIBLE);
        }
    }
}
