package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.view.View;

public class settingsf extends Activity {

    ImageButton b4;
    boolean mess = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        /*b4 = (ImageButton) findViewById(R.id.imageButton4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(settingsf.this, MapsActivity.class));
            }
        });
        */
    }
    public void Observe (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        observa.setTextColor(Color.rgb(178, 178, 178));
        forme.setTextColor(Color.rgb(0, 0, 0));
    }
    public void forme (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        forme.setTextColor(Color.rgb(178, 178, 178));
        observa.setTextColor(Color.rgb(0, 0, 0));
    }
    public void Events (View view)
    {
        Intent ss = new Intent(settingsf.this, activity_event.class);
        settingsf.this.startActivity(ss);
    }
    public void map (View view)
    {
        Intent ss = new Intent(settingsf.this, MapsActivity.class);
        settingsf.this.startActivity(ss);
    }
    public void odkrywaj (View view)
    {
        Intent ss = new Intent(settingsf.this, Search.class);
        settingsf.this.startActivity(ss);
    }
    public void create (View view)
    {
        Intent ss = new Intent(settingsf.this, add_event.class);
        settingsf.this.startActivity(ss);
    }
}