package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Camera;
import android.hardware.camera2.*;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;

import com.google.android.material.snackbar.Snackbar;

import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.VideoView;

import androidx.constraintlayout.widget.ConstraintLayout;

import java.io.IOException;

import static android.content.ContentValues.TAG;

//import static androidx.constraintlayout.Constraints.TAG;

public class home extends Activity{

    VideoView vv;
    ImageButton playpause;
    String video = "iguana";
    String image = "przysto";
    RelativeLayout toolbar;
    ImageButton profile;
    boolean imgmode = false;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    View vw;
    boolean play;
    private long lastTouchDown;
    private static int CLICK_ACTION_THRESHHOLD = 1000;
    int stopPosition;
    int resId;
    boolean left=false;
    boolean right=false;
    boolean down=false;
    boolean up=false;

    @SuppressLint({"ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        vv = (VideoView) findViewById(R.id.videoView);
        String VidPath = "android.resource://"+getPackageName()+"/" + "raw/" + video;
        Uri uri = Uri.parse(VidPath); //Znajdujemy ścieżkę do video
        vv.setVideoURI(uri);
        vv.requestFocus();
        playpause = findViewById(R.id.imageButton7);
        play = false;
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);


        ImageView img = findViewById(R.id.imageView2);
        img.setOnTouchListener(new OnSwipeTouchListener(home.this) {


            public void onSwipeTop() {
                up = true;
            }
            public void onSwipeRight() {
                right = true;
            }
            public void onSwipeLeft() {
                left = true;
            }

            public void onSwipeBottom() {
                down = true;
            }
            public boolean onTouch(View v, MotionEvent event) {
                if(up==true && right == true && down == right && left== right)
                {
                    up=false;
                    right=false;
                    down=false;
                    left=false;
                    //Toast.makeText(getApplicationContext(), "Wersja: XVENT ALPHA 0.01 ", Toast.LENGTH_LONG).show();
                    View contextView = findViewById(R.id.LAYOUT);
                    Snackbar.make(contextView, "Wersja: XVENT ALPHA 0.01  Autorzy:Norman Świątek, Marek Bednarek, Bartosz Gazda", Snackbar.LENGTH_LONG)
                            .show();
                }
                return super.onTouch(v, event);
            }
        });
        vw = (View) findViewById(R.id.view3);
        vw.setOnTouchListener(new OnSwipeTouchListener(home.this) {


            public void onSwipeTop() {
                if(imgmode == false) {
                    video = "iguana";
                    String VidPath = "android.resource://" + getPackageName() + "/" + "raw/" + video;
                    playpause.setVisibility(View.VISIBLE);
                    Uri uri = Uri.parse(VidPath); //Znajdujemy ścieżkę do video
                    vv.setVideoURI(uri);
                    vv.requestFocus();
                    vv.start();
                }
                if(imgmode== true) {
                    playpause.setVisibility(View.INVISIBLE);
                    image = "przysto";
                    resId = getResources().getIdentifier(image, "drawable", getPackageName());
                    vv.setBackgroundResource(resId);
                }

            }
            public void onSwipeRight() {
                if(imgmode == false)
                {
                    image = "przysto";
                    playpause.setVisibility(View.INVISIBLE);
                    resId = getResources().getIdentifier(image, "drawable", getPackageName());
                    vv.setBackgroundResource(resId);
                    vv.pause();
                    imgmode = true;


                }
            }
            public void onSwipeLeft() {
                if(imgmode = true)
                {
                    playpause.setVisibility(View.VISIBLE);
                    vv.setBackgroundResource(0);
                    vv.resume();
                    imgmode = false;
                }

            }

            public void onSwipeBottom() {
                if(imgmode == false)
                {
                    video = "parabole";
                    String VidPath = "android.resource://" + getPackageName() + "/" + "raw/" + video;
                    playpause.setVisibility(View.VISIBLE);
                    Uri uri = Uri.parse(VidPath); //Znajdujemy ścieżkę do video
                    vv.setVideoURI(uri);
                    vv.requestFocus();
                    vv.start();
                }
                if(imgmode == true) {
                    playpause.setVisibility(View.INVISIBLE);
                    image = "ole";
                    resId = getResources().getIdentifier(image, "drawable", getPackageName());
                    vv.setBackgroundResource(resId);
                }
            }
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        lastTouchDown = System.currentTimeMillis();
                        break;
                    case MotionEvent.ACTION_UP:
                        if (System.currentTimeMillis() - lastTouchDown < CLICK_ACTION_THRESHHOLD) {
                            Log.w("App", "You clicked!");
                            if(play == false && imgmode == false)
                            {
                                String VidPath = "android.resource://"+getPackageName()+"/" + "raw/" + video;
                                playpause.setVisibility(View.VISIBLE);


                                Uri uri = Uri.parse(VidPath); //Znajdujemy ścieżkę do video
                                vv.setVideoURI(uri);
                                vv.requestFocus();
                                vv.start();
                                //playpause.setBackgroundResource(R.drawable.cast_ic_mini_controller_pause_large);
                                play = true;
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        playpause.setVisibility(View.INVISIBLE);
                                    }
                                }, 2000);

                            }
                            else if(play == true && imgmode == false )
                            {
                                playpause.setVisibility(View.VISIBLE);
                                vv.stopPlayback();
                                //playpause.setBackgroundResource(R.drawable.cast_ic_mini_controller_play_large);
                                play = false;
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        playpause.setVisibility(View.INVISIBLE);
                                    }
                                }, 2000);
                            }
                        }
                        break;
                }
                return super.onTouch(v, event);
            }
        });
    }
    /*Override
    public void onPause() {
        Log.d(TAG, "onPause called");
        super.onPause();
        stopPosition = vv.getCurrentPosition(); //stopPosition is an int
        vv.pause();
    }
    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume called");
        vv.seekTo(stopPosition);
        vv.start(); //Or use resume() if it doesn't work. I'm not sure
    }
    */




    public void Video(View view) {
        if(play == false)
        {
            String VidPath = "android.resource://"+getPackageName()+"/"+ R.raw.iguana;
            playpause.setVisibility(View.VISIBLE);
            Uri uri = Uri.parse(VidPath); //Znajdujemy ścieżkę do video
            vv.setVideoURI(uri);
            vv.requestFocus();
            vv.start();
            //playpause.setBackgroundResource(R.drawable.cast_ic_mini_controller_pause_large);
            play = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    playpause.setVisibility(View.INVISIBLE);
                }
            }, 2000);

        }
        else if(play == true )
        {
            playpause.setVisibility(View.VISIBLE);
            vv.stopPlayback();
            //playpause.setBackgroundResource(R.drawable.cast_ic_mini_controller_play_large);
            play = false;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    playpause.setVisibility(View.INVISIBLE);
                }
            }, 2000);
        }
    }
    // This snippet hides the system bars.
    public void makephoto(View view)
    {
        Intent ss = new Intent(home.this, camera.class);
        home.this.startActivity(ss);
    }

    public void Observe (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        observa.setTextColor(Color.rgb(178, 178, 178));
        forme.setTextColor(Color.rgb(0, 0, 0));
    }
    public void forme (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        forme.setTextColor(Color.rgb(178, 178, 178));
        observa.setTextColor(Color.rgb(0, 0, 0));
    }
    public void Events (View view)
    {
        Intent ss = new Intent(home.this, activity_event.class);
        home.this.startActivity(ss);
    }
    public void map (View view)
    {
        Intent ss = new Intent(home.this, MapsActivity.class);
        home.this.startActivity(ss);
    }
    public void home (View view)
    {
        Intent ss = new Intent(home.this, home.class);
        home.this.startActivity(ss);
    }
    public void odkrywaj (View view)
    {
        Intent ss = new Intent(home.this, Search.class);
        home.this.startActivity(ss);
    }
    public void create (View view)
    {
        Intent ss = new Intent(home.this, add_event.class);
        home.this.startActivity(ss);
    }
    public void mess (View view)
    {
        Intent ss = new Intent(home.this, chat.class);
        home.this.startActivity(ss);
    }
    public void profile (View view)
    {
        Intent ss = new Intent(home.this, profile.class);
        home.this.startActivity(ss);
    }
    public void ajfo (View view)
    {
        Intent ss = new Intent(home.this, info.class);
        home.this.startActivity(ss);
    }
}
