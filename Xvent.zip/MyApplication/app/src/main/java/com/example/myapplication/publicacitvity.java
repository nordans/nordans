package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.InputStream;

public class publicacitvity extends Activity {

    String eventname;
    String imageUri;
    String desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publicacitvity);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            eventname = extras.getString("eventname");
            imageUri = extras.getString("uri");
            desc = extras.getString("opis");
            //ImageView imv = findViewById(R.id.imageView30);
            Uri fileUri = Uri.parse(imageUri);
            //imv.setImageURI(fileUri);
        }
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
    public void Observe (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        observa.setTextColor(Color.rgb(178, 178, 178));
        forme.setTextColor(Color.rgb(0, 0, 0));
    }
    public void forme (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        forme.setTextColor(Color.rgb(178, 178, 178));
        observa.setTextColor(Color.rgb(0, 0, 0));
    }
    public void Events (View view)
    {
        Intent ss = new Intent(publicacitvity.this, activity_event.class);
        publicacitvity.this.startActivity(ss);
    }
    public void map (View view)
    {
        Intent ss = new Intent(publicacitvity.this, MapsActivity.class);
        publicacitvity.this.startActivity(ss);
    }
    public void odkrywaj (View view)
    {
        Intent ss = new Intent(publicacitvity.this, Search.class);
        publicacitvity.this.startActivity(ss);
    }
    public void create (View view)
    {
        Intent ss = new Intent(publicacitvity.this, add_event.class);
        publicacitvity.this.startActivity(ss);
    }
    public void open(View view)
    {
        Intent ss = new Intent(publicacitvity.this, info.class);
        ss.putExtra("eventname", eventname);
        ss.putExtra("uri", imageUri);
        ss.putExtra("opis", desc);
        publicacitvity.this.startActivity(ss);
    }
}
