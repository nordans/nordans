package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class RegisterLogin extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private static final String succ = "Sukces !";
    private static final String error = "Błąd !";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_register_login);
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        mAuth = FirebaseAuth.getInstance();
    }
    String login;
    String password;
    String email;
    String data;
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        //FirebaseAuth.getInstance().signOut();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }
    public void updateUI(FirebaseUser account){

        if(account != null){
            Toast.makeText(this,"Zalogowałeś się !",Toast.LENGTH_LONG).show();
            startActivity(new Intent(this,home.class));


        }else {
            Toast.makeText(this,"Nie jesteś zalogowany.",Toast.LENGTH_LONG).show();
        }

    }
    public void Rejestracja(View view) {
        Button b = findViewById(R.id.button16);
        Button b1 = findViewById(R.id.button17);
        Button b2 = findViewById(R.id.button18);
        ConstraintLayout a = findViewById(R.id.Rejestracja);
        ConstraintLayout ok = findViewById(R.id.register);
        ImageButton f = findViewById(R.id.imageButton);
        a.setVisibility(View.VISIBLE);
        b2.setVisibility(View.VISIBLE);
        b1.setVisibility(View.INVISIBLE);
        b.setVisibility(View.INVISIBLE);
        ok.setBackgroundColor(Color.WHITE);
    }
    public void Logowanie(View view) {
        ConstraintLayout ok = findViewById(R.id.register);
        ConstraintLayout main = findViewById(R.id.main);
        ConstraintLayout loge = findViewById(R.id.Logowanie);
        ImageButton f = findViewById(R.id.imageButton);
        main.setVisibility(View.INVISIBLE);
        loge.setVisibility(View.VISIBLE);
        ok.setBackgroundColor(Color.WHITE);
    }
    public void Login(View view) {
        TextInputEditText tex = findViewById(R.id.mail);
        TextInputEditText tex2 = findViewById(R.id.newa);
        password = tex2.getText().toString();
        email = tex.getText().toString();
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(succ, "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                            Intent ss = new Intent(RegisterLogin.this, home.class);
                            RegisterLogin.this.startActivity(ss);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(error, "signInWithEmail:failure", task.getException());
                            Toast.makeText(RegisterLogin.this, "Nieprawidłowe dane.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // ...
                    }
                });
    }
    public void admin(View view)
    {
        Intent ss = new Intent(RegisterLogin.this, home.class);
        RegisterLogin.this.startActivity(ss);
    }
    public void Register(View view)
    {
        TextInputEditText i = findViewById(R.id.pas);
        TextInputEditText o = findViewById(R.id.email);
        password = i.getText().toString();
        email = o.getText().toString();
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(succ, "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                            Intent ss = new Intent(RegisterLogin.this, home.class);
                            user.sendEmailVerification();
                            RegisterLogin.this.startActivity(ss);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(error, "createUserWithEmail:failure", task.getException());
                            Toast.makeText(RegisterLogin.this, "Nieprawidłowe dane.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // ...
                    }
                });

    }
}
