package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

public class Search extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        View view = findViewById(R.id.www);
        view.setOnTouchListener(new OnSwipeTouchListener(Search.this) {
            public void onSwipeTop() {
            }
            public void onSwipeRight() {
                Intent ss = new Intent(Search.this, privateactivity.class);
                Search.this.startActivity(ss);
            }
            public void onSwipeLeft() {
                Intent ss = new Intent(Search.this, publicacitvity.class);
                Search.this.startActivity(ss);
            }
            public void onSwipeBottom() {
            }
        });
    }
    public void Observe (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        observa.setTextColor(Color.rgb(178, 178, 178));
        forme.setTextColor(Color.rgb(0, 0, 0));
    }
    public void forme (View view)
    {
        Button observa = (Button) findViewById(R.id.button9);
        Button forme = (Button) findViewById(R.id.button10);
        forme.setTextColor(Color.rgb(178, 178, 178));
        observa.setTextColor(Color.rgb(0, 0, 0));
    }
    public void Events (View view)
    {
        Intent ss = new Intent( Search.this, activity_event.class);
        Search.this.startActivity(ss);
    }
    public void map (View view)
    {
        Intent ss = new Intent( Search.this, MapsActivity.class);
        Search.this.startActivity(ss);
    }
    public void odkrywaj (View view)
    {
        Intent ss = new Intent( Search.this, Search.class);
        Search.this.startActivity(ss);
    }
    public void create (View view)
    {
        Intent ss = new Intent( Search.this, add_event.class);
        Search.this.startActivity(ss);
    }
    public void home (View view)
    {
        Intent ss = new Intent(Search.this, home.class);
        Search.this.startActivity(ss);
    }
}
