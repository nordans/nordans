package com.example.myapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.TextureView;
import androidx.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.example.myapplication.R;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import com.google.common.util.concurrent.ListenableFuture;
import androidx.camera.camera2.Camera2Config;
import androidx.camera.core.CameraXConfig;
import androidx.camera.view.PreviewView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.lifecycle.LifecycleOwner;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.ExecutionException;

public class camera extends AppCompatActivity implements CameraXConfig.Provider {
    private CameraCaptureSession myCameraCaptureSession;
    private String myCameraID;
    private CameraManager myCameraManager;
    private CameraDevice myCameraDevice;
    private TextureView myTextrureView;
    private CaptureRequest.Builder myCaptureRequestBuilder;
    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;
    private static final int CAMERA_REQUEST = 1888;
    private ImageView imageView;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    public EditText edt;
    int first = 0;
    float txtsize = 15;
    Context context;
    private final static int START_DRAGGING = 0;
    private final static int STOP_DRAGGING = 1;
    private int status;
    int flag=0;
    ConstraintLayout cst;
    float xAxis = 0f;
    float yAxis = 0f;
    float lastXAxis = 0f;
    float lastYAxis = 0f;
    static final int REQUEST_VIDEO_CAPTURE = 1;
    Button btn;


    PreviewView pv;
    private PaintView paintView;

    @NonNull
    @Override
    public CameraXConfig getCameraXConfig() {
        return Camera2Config.defaultConfig();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        setContentView(R.layout.activity_camera);
        cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        edt = findViewById(R.id.Napis);
        edt.setOnTouchListener(mOnTouchListenerTv2);
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                bindPreview(cameraProvider);
            } catch (ExecutionException | InterruptedException e) {
                // No errors need to be handled for this Future.
                // This should never be reached.
            }
        }, ContextCompat.getMainExecutor(this));
        pv = findViewById(R.id.previewView);
        pv.setOnClickListener(new DoubleClickListener() {

            @Override
            public void onSingleClick(View v) {

            }

            @Override
            public void onDoubleClick(View v) {
                PreviewView pv;
                if (first == 0) {
                    pv = findViewById(R.id.previewView);
                    ViewGroup.LayoutParams params = pv.getLayoutParams();
                    double roznicax;
                    double roznicay;
                    int x;
                    int y;
                    x = pv.getHeight();
                    y = pv.getWidth();
                    roznicax = x * 2;
                    roznicay = y * 2;
                    int zium = (int) roznicax;
                    int zium2 = (int) roznicay;
                    params.height = x + zium;
                    params.width = y + zium2;
                    pv.setLayoutParams(params);
                    first = 1;
                    Toast.makeText(getApplicationContext(), "2.0", Toast.LENGTH_LONG).show();
                } else if (first == 1) {
                    pv = findViewById(R.id.previewView);
                    FrameLayout container;
                    container = findViewById(R.id.container);
                    ViewGroup.LayoutParams params = pv.getLayoutParams();
                    ViewGroup.LayoutParams se = container.getLayoutParams();
                    int x;
                    int y;
                    x = container.getHeight();
                    y = container.getWidth();
                    params.height = x;
                    params.width = y;
                    pv.setLayoutParams(params);
                    first = 0;
                    Toast.makeText(getApplicationContext(), "1.0", Toast.LENGTH_LONG).show();
                }
            }
        });
        paintView = (PaintView) findViewById(R.id.paintView);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        paintView.init(metrics);
        btn = findViewById(R.id.button15);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v ) {
                cst = findViewById(R.id.menu);
                cst.setVisibility(View.INVISIBLE);
                btn.setVisibility(View.INVISIBLE);
                Bitmap bitmap;
                View v1 = findViewById(R.id.linearLayout);// get ur root view id
                v1.setDrawingCacheEnabled(true);
                bitmap = Bitmap.createBitmap(v1.getDrawingCache());
                v1.setDrawingCacheEnabled(false);

                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 40, bytes);
                File f = new File(Environment.getExternalStorageDirectory()
                        + File.separator + "photo.jpg");
                try {
                    f.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                FileOutputStream fo = null;
                try {
                    fo = new FileOutputStream(f);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                try {
                    fo.write(bytes.toByteArray());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    fo.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                cst.setVisibility(View.VISIBLE);
                btn.setVisibility(View.VISIBLE);
            }
        });
    }
    public final View.OnTouchListener mOnTouchListenerTv2 = new View.OnTouchListener() {
        int prevX, prevY;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            final ConstraintLayout.LayoutParams par = (ConstraintLayout.LayoutParams) v.getLayoutParams();
            switch (event.getAction()) {
                case MotionEvent.ACTION_MOVE: {
                    par.topMargin += (int) event.getRawY() - prevY;
                    prevY = (int) event.getRawY();
                    par.leftMargin += (int) event.getRawX() - prevX;
                    prevX = (int) event.getRawX();
                    v.setLayoutParams(par);
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    par.topMargin += (int) event.getRawY() - prevY;
                    par.leftMargin += (int) event.getRawX() - prevX;
                    v.setLayoutParams(par);
                    return true;
                }
                case MotionEvent.ACTION_DOWN: {
                    prevX = (int) event.getRawX();
                    prevY = (int) event.getRawY();
                    par.bottomMargin = -2 * v.getHeight();
                    par.rightMargin = -2 * v.getWidth();
                    v.setLayoutParams(par);
                    return true;
                }
                case MotionEvent.ACTION_SCROLL: {
                    txtsize++;
                    edt.setTextSize(txtsize);
                }
            }
            return false;
        }
    };
    private void dispatchTakeVideoIntent() {
        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
        }
    }

    public void Normal(View view) {
        paintView.normal();
    }

    public void Embes(View view) {
        paintView.emboss();
    }

    public void Blur(View view) {
        paintView.blur();
    }

    public void Clear(View view) {
        paintView.clear();
    }

    /*   @Override
       public boolean onCreateOptionsMenu(Menu menu) {
           MenuInflater menuInflater = getMenuInflater();
           menuInflater.inflate(R.menu.main, menu);
           return super.onCreateOptionsMenu(menu);
       }
       @Override
       public boolean onOptionsItemSelected(MenuItem item) {
           switch(item.getItemId()) {
               case R.id.normal:
                   paintView.normal();
                   return true;
               case R.id.embos:
                   paintView.emboss();
                  return true;
               case R.id.blur:
                   paintView.blur();
                  return true;
              case R.id.clear:
                   paintView.clear();
                   return true;
           }

           return super.onOptionsItemSelected(item);

       }

     */
    public abstract class DoubleClickListener implements View.OnClickListener {

        private static final long DOUBLE_CLICK_TIME_DELTA = 300;//milliseconds

        long lastClickTime = 0;

        @Override
        public void onClick(View v) {
            long clickTime = System.currentTimeMillis();
            if (clickTime - lastClickTime < DOUBLE_CLICK_TIME_DELTA) {
                onDoubleClick(v);
            } else {
                try {
                    onSingleClick(v);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            lastClickTime = clickTime;
        }

        public abstract void onSingleClick(View v) throws IOException;

        public abstract void onDoubleClick(View v);

        {
        }
    }

    void bindPreview(@NonNull ProcessCameraProvider cameraProvider) {
        Preview preview = new Preview.Builder()
                .build();

        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build();
        PreviewView previewView = findViewById(R.id.previewView);
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        Camera camera = cameraProvider.bindToLifecycle((LifecycleOwner) this, cameraSelector, preview);


    }

    @SuppressLint("ResourceAsColor")
    public void text(View view) {
        edt = findViewById(R.id.Napis);
        edt.setVisibility(View.VISIBLE);
    }
}

