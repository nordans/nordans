package com.example.myapplication;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.content.ContentValues.TAG;

public class info extends Activity {

    private DatabaseReference mDatabase;
    String desc;
    int eventype;
    int follow;
    int join;
    TextView tx1;
    TextView tx2;
    String name;
    int relation;
    int relationview;
    int saveandcomment;
    ConstraintLayout vie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        Bundle extras = getIntent().getExtras();
        tx1 = findViewById(R.id.textView44);
        tx2 = findViewById(R.id.textView25);
        mDatabase = FirebaseDatabase.getInstance().getReference().child("events");
        mDatabase.child("refresh").setValue(3);
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                desc = dataSnapshot.child("description").getValue().toString();
                eventype = dataSnapshot.child("eventype").getValue().hashCode();
                follow = dataSnapshot.child("follow").getValue().hashCode();
                join = dataSnapshot.child("join").getValue().hashCode();
                name = dataSnapshot.child("name").getValue().toString();
                relation = dataSnapshot.child("relation").getValue().hashCode();
                relationview = dataSnapshot.child("relationview").getValue().hashCode();
                saveandcomment = dataSnapshot.child("saveandcomment").getValue().hashCode();
                tx1.setText(name);
                tx2.setText(desc);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
        //        <item name="android:windowIsFloating">true</item>
        //        <item name="android:backgroundDimEnabled">false</item>
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
    public void infosz(View view)
    {
        ScrollView sv = findViewById(R.id.sc1);
        sv.setRotation(50);
        RotateAnimation animation = new RotateAnimation(50f, 100f);
        animation.setDuration(100);
        animation.setFillAfter(true);
        sv.startAnimation(animation);
    }
    public void back (View view)
    {
        vie = findViewById(R.id.jd);
        TranslateAnimation animate = new TranslateAnimation(
                0,
                0,
                0,
                vie.getHeight());
        animate.setDuration(500);
        animate.setFillAfter(true);
        vie.startAnimation(animate);
        this.finish();
    }
}
