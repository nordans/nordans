package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.renderscript.Sampler;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.Path;

import java.util.ArrayList;
import java.util.List;

public class chat extends AppCompatActivity {
    DatabaseReference mDatabase;
    DatabaseReference mDatabase1;
    DataSnapshot snapshotek;
    String sciezka;
    TextInputEditText mymsg;
    String wiadomosc;
    TextView asd;
    String temporary;
    int i=0;
    private String[] id;
    private TextView[] textViews = new TextView[32];
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        mymsg = (TextInputEditText) findViewById(R.id.msginput);
        Button btn1 = findViewById(R.id.Send);
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        btn1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                mDatabase= FirebaseDatabase.getInstance().getReference().child("message");
                wiadomosc = mymsg.getText().toString();
                closeKeyboard();
                mDatabase.child("msg1").setValue(wiadomosc);
                mymsg.getText().clear();
                mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        temporary = snapshot.child("nrwiado").getValue().toString();
                        i = Integer.parseInt(temporary);
                        i++;
                        mDatabase.child("nrwiado").setValue(i);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                mDatabase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(i>=21)
                        {
                            mDatabase= FirebaseDatabase.getInstance().getReference().child("message");
                            mDatabase.child("nrwiado").setValue("0");
                            i = 0;
                        }
                        String message1 = snapshot.child("msg1").getValue().toString();
                        String message2 = snapshot.child("msg2").getValue().toString();
                        int temp;
                        id = new String[]{"msg1", "msg2", "msg3", "msg4", "msg5", "msg6", "msg7", "msg8", "msg9", "msg10", "msg11", "msg12", "msg13", "msg14", "msg15", "msg16", "msg17", "msg18", "msg19", "msg20", "msg21"};
                        temp = getResources().getIdentifier(id[i], "id", getPackageName());
                        textViews[i] = (TextView) findViewById(temp);
                        textViews[i].setText(message1);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        i = -1;
                    }
                });
            }
        });
    }
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    public void ulala(View view) {
        Intent ss = new Intent(chat.this, messenger.class);
        chat.this.startActivity(ss);

    }
}
